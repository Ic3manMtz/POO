public class App{
   public static void main(String[] args) {
      ATMGUI atm = new ATMGUI();
      atm.menuPrincipal();
   }
}
